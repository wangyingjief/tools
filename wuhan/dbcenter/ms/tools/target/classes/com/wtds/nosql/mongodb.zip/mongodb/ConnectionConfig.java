package com.wtds.nosql.mongodb;

/**
 * MongoDb数据库链接配置信息
 * @author wyj
 *
 */
public class ConnectionConfig {
	
	/**
	 * 服务器地址
	 */
	private String host;
	
	/**
	 * 端口
	 */
	private int port = 27017;
	
	/**
	 * 登陆名
	 */
	private String userName;
	
	/**
	 * 登陆的数据库名
	 */
	private String databaseName;
	
	/**
	 * 登陆密码
	 */
	private String password;

	public String getHost() {
		return host;
	}

	public void setHost(String host) {
		this.host = host;
	}

	public int getPort() {
		return port;
	}

	public void setPort(int port) {
		this.port = port;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getDatabaseName() {
		return databaseName;
	}

	public void setDatabaseName(String databaseName) {
		this.databaseName = databaseName;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}
	
	
}
