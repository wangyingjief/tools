package com.wtds.nosql.mongodb;

import org.bson.Document;
import org.bson.conversions.Bson;
import org.bson.types.ObjectId;

import com.mongodb.BasicDBObject;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoCursor;
import com.mongodb.client.model.Filters;
import com.mongodb.client.result.DeleteResult;

public class MongoManager {
	
	MongoCollection<Document> coll;
	
	@SuppressWarnings("unused")
	private MongoManager(){}
	
	public MongoManager(MongoCollection<Document> mongoCollection) {
		this.coll = mongoCollection;
	}
	
	
	/**
     * 查找对象 - 根据主键_id
     * 
     * @param id
     * @return
     */
    public Document findById(String id) {
        ObjectId _idobj = null;
        try {
            _idobj = new ObjectId(id);
        } catch (Exception e) {
            return null;
        }
        Document myDoc = coll.find(Filters.eq("_id", _idobj)).first();
        return myDoc;
    }
    
    /** 统计数 */
    public int getCount() {
        int count = (int) coll.count();
        return count;
    }
    
    /** 条件查询 */
    public MongoCursor<Document> find(Bson filter) {
        return coll.find(filter).iterator();
    }
    
    /** 条件查询 */
    public MongoCursor<Document> find() {
        return coll.find().iterator();
    }


    /** 分页查询 */
    public MongoCursor<Document> findByPage(Bson filter, int pageNo, int pageSize) {
        Bson orderBy = new BasicDBObject("_id", 1);
        return coll.find(filter).sort(orderBy).skip((pageNo - 1) * pageSize).limit(pageSize).iterator();
    }

    /**
     * 通过ID删除
     * 
     * @param id
     * @return
     */
    public int deleteById(String id) {
        int count = 0;
        ObjectId _id = null;
        try {
            _id = new ObjectId(id);
        } catch (Exception e) {
            return 0;
        }
        Bson filter = Filters.eq("_id", _id);
        DeleteResult deleteResult = coll.deleteOne(filter);
        count = (int) deleteResult.getDeletedCount();
        return count;
    }
    

    /**
     * 修改
     * @param id
     * @param newdoc
     * @return
     */
    public Document updateById(String id, Document newdoc) {
        ObjectId _idobj = null;
        try {
            _idobj = new ObjectId(id);
        } catch (Exception e) {
            return null;
        }
        Bson filter = Filters.eq("_id", _idobj);
        // coll.replaceOne(filter, newdoc); // 完全替代
        coll.updateOne(filter, new Document("$set", newdoc));
        return newdoc;
    }
    
    /**
     * 插入数据
     * @param doc
     */
    public void insert(Document doc) {
    	coll.insertOne(doc);
    }
    
}
