package com.wtds.nosql.mongodb;
import org.bson.Document;

import com.mongodb.client.MongoCollection;

/**
 * MongoDb接口
 * @author wyj
 *
 */
public interface MongoDb {
	
	/**
	 * 获取MongoDb链接
	 * @param tableName 表名
	 * @return
	 */
	public MongoCollection<Document> getCollection(String tableName);
	
	/**
	 * 关闭数据库
	 */
	public void close();
}
