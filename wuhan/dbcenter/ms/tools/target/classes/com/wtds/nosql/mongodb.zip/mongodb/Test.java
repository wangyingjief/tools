package com.wtds.nosql.mongodb;

import org.bson.Document;
import org.bson.conversions.Bson;

import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoCursor;
import com.mongodb.client.model.Filters;
import com.wtds.nosql.mongodb.impl.MongoDbExample;

public class Test {

	public static void main(String[] args) {
//		MongoDb db = new MongoDbExample();
//		MongoCollection<Document> mc = db.getCollection("sdr");
//
//		MongoManager m = new MongoManager(mc);
//
//		// 插入
////		Document doc = new Document();
////		doc.put("MsgID", "MSH-10");
////		doc.put("HL7Body", "HL7Msg");
////
////		m.insert(doc);
//		
//		//查询
//		Bson filter = Filters.eq("a", "1");
//		MongoCursor<Document> mc2 = m.find(filter);
//		System.out.println(mc2.hasNext());
//		while(mc2.hasNext()) {
//			System.out.println(mc2.next().toJson());
//		}
		
	}
}
