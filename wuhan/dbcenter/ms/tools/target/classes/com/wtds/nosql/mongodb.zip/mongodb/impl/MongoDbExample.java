package com.wtds.nosql.mongodb.impl;

import java.util.ArrayList;
import java.util.List;
import java.util.Properties;

import org.bson.Document;

import com.mongodb.MongoClient;
import com.mongodb.MongoCredential;
import com.mongodb.ServerAddress;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoDatabase;
import com.wtds.nosql.mongodb.ConnectionConfig;
import com.wtds.nosql.mongodb.MongoDb;
import com.wtds.tools.PropertiesUtil;
import com.wtds.tools.StringUtil;

/**
 * 实例Mongodb
 * @author joymting
 *
 */
public class MongoDbExample implements MongoDb{
	
	ConnectionConfig config;
	
	MongoClient mongoClient;
	
	MongoDatabase mongoDatabase;
	
	Properties properties;
	
	private String defaultPath = "\\config\\mongodb.properties";
	
	public MongoDbExample() {
		initProperties(System.getProperty("user.dir") + defaultPath);
	}
	
	public MongoDbExample(ConnectionConfig config) {
		this.initConfig(config);
	}
	
	public MongoDbExample(String configPath) {
		this.initProperties(configPath);
	}
	
	private void initProperties(String configPath) {
		properties = PropertiesUtil.getProperties(configPath);
		if(properties != null) {
			if(config == null) {
				config = new ConnectionConfig();
			}
			config.setDatabaseName(properties.get("databaseName")+"");
			config.setHost(properties.get("host")+"");
			config.setPassword(properties.get("password")+"");
			config.setPort(Integer.parseInt(properties.get("port")+""));
			config.setUserName(properties.get("userName")+"");
			this.initConfig(config);
		}
	}
	
	private void initConfig(ConnectionConfig config) {
		this.config = config;
		this.initClient();
	}
	
	private void initClient() {
		if(StringUtil.isEmpty(config.getUserName())) {
			this.initNotLoginClient();
		}
		if(!StringUtil.isEmpty(config.getUserName()) && !StringUtil.isEmpty(config.getPassword())) {
			this.initExistClient();
		}
		
	}
	
	/**
	 * 无登陆密码连接
	 */
	private void initNotLoginClient() {
		try {
			// 连接到 mongodb 服务
			mongoClient = new MongoClient(config.getHost(), config.getPort());
			
			// 连接到数据库
			mongoDatabase = mongoClient.getDatabase(config.getDatabaseName());
			System.out.println("Connect to mogodb["+config.getDatabaseName()+"] successfully!");

		} catch (Exception e) {
			System.err.println(e.getClass().getName() + ": " + e.getMessage());
		}
	}
	
	/**
	 * 有登陆密码连接
	 */
	private void initExistClient() {
		try {  
            //连接到MongoDB服务 如果是远程连接可以替换“localhost”为服务器所在IP地址  
            //ServerAddress()两个参数分别为 服务器地址 和 端口  
            ServerAddress serverAddress = new ServerAddress(config.getHost(),config.getPort());  
            List<ServerAddress> addrs = new ArrayList<ServerAddress>();  
            addrs.add(serverAddress);  
              
            //MongoCredential.createScramSha1Credential()三个参数分别为 用户名 数据库名称 密码  
            MongoCredential credential = MongoCredential.createScramSha1Credential(config.getUserName(), config.getDatabaseName(), config.getPassword().toCharArray());  
            List<MongoCredential> credentials = new ArrayList<MongoCredential>();  
            credentials.add(credential);  
              
            //通过连接认证获取MongoDB连接  
            mongoClient = new MongoClient(addrs,credentials);  
            
            //连接到数据库  
            mongoDatabase = mongoClient.getDatabase(config.getDatabaseName());  
            System.out.println("Connect to mogodb["+config.getDatabaseName()+"] successfully!");
        } catch (Exception e) {  
            System.err.println( e.getClass().getName() + ": " + e.getMessage() );  
        }  
	}
	
	public MongoClient getMongoClient() {
		return mongoClient;
	}
	
	public MongoDatabase getMongoDatabase() {
		return mongoDatabase;
	}
	
	public String getDefaultPath() {
		return defaultPath;
	}

	public void setDefaultPath(String defaultPath) {
		this.defaultPath = defaultPath;
	}

	/**
	 * 获取表
	 */
	public MongoCollection<Document> getCollection(String tableName) {
		return mongoDatabase.getCollection(tableName);
	}

	public void close() {
		if(mongoClient != null) {
			mongoClient.close();
			mongoClient = null;
		}
	}
	
	
}
