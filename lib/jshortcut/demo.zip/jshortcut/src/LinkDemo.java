import javax.swing.filechooser.FileSystemView;

import net.jimmc.jshortcut.JShellLink;


public class LinkDemo {
	public static void main(String[] args){
		createShortcut();
	}
		
	private static void createShortcut() {
        // ��ȡϵͳ����·��
        String desktop = FileSystemView.getFileSystemView().getHomeDirectory().getAbsolutePath();
        // ����ִ���ļ�·��
        //String path = System.getProperty("user.dir") + "\\appName.exe";
        String path2 = "C:\\Program Files (x86)\\Tencent\\WeChat\\WeChat.exe";
 
        JShellLink link = new JShellLink();
        System.out.println("1ok");
        link.setFolder(desktop); // ��ݷ�ʽ��ŵ�ַ
        System.out.println("2ok");
        link.setName("demo"); // ��ݷ�ʽ����
        System.out.println("3ok");
        link.setPath(path2); // ��ݷ�ʽָ���ַ
        System.out.println("4ok");
        link.setArguments("form"); //���ò���
        System.out.println("5ok");
        link.save();
        System.out.println("6ok");
         
    }

}
